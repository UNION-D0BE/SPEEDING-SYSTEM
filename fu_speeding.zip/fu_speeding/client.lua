vRP = Proxy.getInterface("vRP")
frontend = {}
Tunnel.bindInterface(GetCurrentResourceName(), frontend)
Proxy.addInterface(GetCurrentResourceName(), frontend)
backend = Tunnel.getInterface(GetCurrentResourceName(), GetCurrentResourceName())

local poco = {
    -- 상태 확인
    poco_a = false,
    -- 전망 카메라
	a_plate = "미감지",
	a_speed = 0,
    a_maxspeed = 0,
    -- 후방 카메라
	b_plate = "미감지",
	a_speed = 0,
    b_maxspeed = 0,
}

Citizen.CreateThread(function()
    while true do
        local ped = GetPlayerPed(-1)
        if IsPedInAnyVehicle(ped, false) then
            if IsControlJustPressed(1, 110) then
                backend.haspermission({}, function(p_server)
                    if p_server then
                        if not poco.poco_a then
                            SendNUIMessage({
                                type = "show"
                            })
                            poco.poco_a = true
                        else
                            if poco.poco_a then
                                SendNUIMessage({
                                    type = "hide"
                                })
                                poco.poco_a = false
                            end
                        end
                    end
                end)
            end
        else
            if poco.poco_a then
                SendNUIMessage({
                    type = "hide"
                })
                poco.poco_a = false
            end
        end
        Citizen.Wait(5)
    end
end)

Citizen.CreateThread(function()
    while true do
        local ped = GetPlayerPed(-1)
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
            local coordA = GetOffsetFromEntityInWorldCoords(veh, 0.0, 1.0, 1.0)
            local coordB = GetOffsetFromEntityInWorldCoords(veh, 0.0, 105.0, 0.0)
            local frontcar = StartShapeTestCapsule(coordA, coordB, 3.0, 10, veh, 7)
            local a, b, c, d, e = GetShapeTestResult(frontcar)

            if IsEntityAVehicle(e) then
                local fmodel = GetDisplayNameFromVehicleModel(GetEntityModel(e))
                local fvspeed = GetEntitySpeed(e) * 3.6
                local fplate = GetVehicleNumberPlateText(e)
                poco.a_speed = math.ceil(fvspeed)
                if fplate == poco.a_plate then
                    print("0")
                    if fvspeed > poco.a_maxspeed then
                        print("1")
                        poco.a_maxspeed = math.ceil(fvspeed)
                    end
                else
                    if poco.a_maxspeed ~= 0 then 
                        poco.a_maxspeed = 0
                    end
                end
                poco.a_plate = fplate
            end
            
            local bcoordB = GetOffsetFromEntityInWorldCoords(veh, 0.0, -105.0, 0.0)
            local rearcar = StartShapeTestCapsule(coordA, bcoordB, 3.0, 10, veh, 7)
            local f, g, h, i, j = GetShapeTestResult(rearcar)
            
            if IsEntityAVehicle(j) then
                local bmodel = GetDisplayNameFromVehicleModel(GetEntityModel(j))
                local bvspeed = GetEntitySpeed(j) * 3.6
                local bplate = GetVehicleNumberPlateText(j)
                -- poco.b_plate = bplate
                poco.b_speed = math.ceil(bvspeed)
                if bplate == poco.b_plate then
                    print("0")
                    if bvspeed > poco.b_maxspeed then
                        print("1")
                        poco.b_maxspeed = math.ceil(bvspeed)
                    end
                else
                    if poco.b_maxspeed ~= 0 then 
                        poco.b_maxspeed = 0
                    end
                end
                poco.b_plate = bplate
            end
            
            SendNUIMessage({
                type = "update",
                data = poco
            })

        end
        Citizen.Wait(50)
    end
end)