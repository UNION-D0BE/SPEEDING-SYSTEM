window.addEventListener("message", function(event){
    var data = event.data;
    if (data) {
        switch (data.type) {
            case "show":
                $(".main").show()
                break;
            case "hide":
                $(".main").hide()
                break;
            case "update":
                $("#a_plate").text(data.data.a_plate)
                $("#a_speed").text(data.data.a_speed)
                $("#a_maxspeed").text(data.data.a_maxspeed)
                $("#b_plate").text(data.data.b_plate)
                $("#b_speed").text(data.data.b_speed)
                $("#b_maxspeed").text(data.data.b_maxspeed)
                break;
        }
    }
});