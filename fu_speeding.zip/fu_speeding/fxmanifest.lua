fx_version 'cerulean'
game 'gta5'

client_scripts {
	"@vrp/client/Proxy.lua",
	"@vrp/client/Tunnel.lua",
  	"client.lua"
}
server_scripts {
	"@vrp/lib/utils.lua",
  	"server.lua",
	"config.lua"
}

ui_page "html/index.html"

files {
	"html/*.*"
}